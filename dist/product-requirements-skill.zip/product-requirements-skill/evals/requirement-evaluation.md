# Requirement 评估

- 八要素齐全；未知写 TBD，不编预算、日期、指标或业务规则。
- REQ ID 唯一稳定，重跑沿用旧 ID，新需求取最大序号加一。
- 角色、场景、痛点、目标、范围、约束、依赖和 Evidence 互相对应。
- 状态只用 draft/confirmed/disputed/parked/cancelled；证据等级不代替状态。
- 验收包含可执行动作与预期，正常和关键异常可区分。
- 重复需求保留复述证据但不新增 REQ；冲突并列展示。
- 整条锁定和字段锁定在自动合并前检查；人工变更形成记录。
- ChangeSet 展示旧值、新值、来源和影响，未经批准不更新 Baseline。
